package com.example.internettv.thirdparty;

public class TitleNotFoundException extends Exception {

}
