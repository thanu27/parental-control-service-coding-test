package com.example.internettv.thirdparty;

public class TechnicalFailureException extends Exception {

}
